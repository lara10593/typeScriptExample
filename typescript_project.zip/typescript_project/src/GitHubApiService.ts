import * as req from 'request'
import { user } from './user'
import { Repo } from './Repo'
import request = require('request')
// we can use this const method inside the request.get method also if its method specific
// else we can use like this for global usages
const OPTIONS: any = {
    // github thrown an error that needs the value of a user agent for the request
    headers : {
        'user-agent':'request'
    },
    
    json:true
}
// export the class to import it into other class
export class GitHubApiService
{

    getUserInfo(username : string,cb: (user1:user) => any )
    {
       //request to get the value from the REST URL 
        request.get("https://api.github.com/users/"+username,OPTIONS,(error:any,Response: any,body:any) => {
            // the response of the rest call is set to the model class using a constructor.
            let user1 = new user(body);
            // call back function to return the data
            cb(user1);
        }
        
        );
    }

    getRepos(username : string,cb: (repos:Repo[]) => any)
    {
        console.log("inside getRepos service "+username);
        request.get("https://api.github.com/users/"+username+"/repos",OPTIONS,(error:any,Response: any,body:any) => {
           let repos =  body.map((repo:any) => new Repo(repo));
         cb(repos);
        }
        
        );
    }
}