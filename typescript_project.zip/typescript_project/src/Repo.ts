export class Repo 
{
    name: string;
    Description: string;
    URL : string;
    Size: number;
    ForksCount: number;

// constructor to set the value from the response 
    constructor (repo : any)
    {
        this.name = repo.name;
        this.Description = repo.description;
        this.URL = repo.html_url;
        this.Size = repo.size;
        this.ForksCount = repo.forks;
    }
}