import {GitHubApiService} from './GitHubApiService';
// import a exported class inside a class to reuse the functionality
import { user } from './user';
import { Repo } from './Repo';
import * as lo_ from 'lodash';
// lodash is a library which has many use full methods like map and take in this class
console.log("hello");
let svc = new GitHubApiService();
// let allows you to create a instance variable => variable of objects,arrays etc..
//process.argv by default has 2 values so argv[2] is the first value we enter after npm start command
if(process.argv.length < 3)
{
    console.log("please enter the user name");
}
else
{
let username=process.argv[2];
// user info method goes for a service call to service class and returns a user object with data from a request
// we use callback function inside this method call to get the return value like we use in java
svc.getUserInfo(username, (user1: user) =>{
    // similarly for Repos we use a call back to get an array of repository inside service class
    svc.getRepos(user1.login, (repo1:Repo[]) =>{
        let Srepos1 = lo_.sortBy(repo1,[(repo:Repo) => repo.ForksCount * -1])
        // above method sort the repo based on forkcount in descending order using -1
        // now we are gonna take top 3 of them and store it user using lodash take method
        let Frepos1 = lo_.take(Srepos1,3);
        user1.repos = Frepos1;
        console.log(user1);
    }
    );
}); 
}


  