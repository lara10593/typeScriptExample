import { Repo } from "./Repo";

export class user
{
login : string;
Fullname : string;
RepoCount : number;
FollowerCount : number;
repos : Repo[];

// constructor to set the value from the response 
constructor(userResponse:any)
{
this.login = userResponse.login;
this.Fullname = userResponse.name;
this.RepoCount = userResponse.public_repos;
this.FollowerCount = userResponse.followers;

}

}

